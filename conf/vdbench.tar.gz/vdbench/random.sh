
for i in 1 2 4 8 16 ; do a=$(expr $i \* 2 )  ; for e in 8 16 32 64 128 ; do b=$(expr $e \* 2 ) ; cat random.cfg ; vdbench/vdbench -f random.cfg -o /root/random-threads-"$i"_size-"$e" ; sed -i s/size="$e"k/size="$b"k/ random.cfg  ; done ; sed -i s/size=256k/size=8k/ random.cfg ; sed -i s/threads=$i/threads=$a/ random.cfg ; done ; sed -i s/threads=32/threads=1/ random.cfg
 

